﻿namespace SCM_API.Models.Course
{
    public class CourseIndexViewModel
    {
        public CourseViewModel[] Courses { get; set; }
        public CourseSearchViewModel CourseSearch { get; set; }
    }
}