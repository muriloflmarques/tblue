﻿namespace SCM_API.Models.Student
{
    public class StudentIndexViewModel
    {
        public StudentViewModel[] Students { get; set; }
        public StudentSearchViewModel StudentSearch { get; set; }
    }
}