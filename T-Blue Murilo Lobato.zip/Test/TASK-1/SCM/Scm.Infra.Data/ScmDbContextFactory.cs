﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Smc.Infra.Data
{
    public class ScmDbContextFactory : IDesignTimeDbContextFactory<ScmDbContext>
    {
        public ScmDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ScmDbContext>();
            optionsBuilder.UseSqlServer("CONNECTION_STRING");

            return new ScmDbContext(optionsBuilder.Options);
        }
    }
}